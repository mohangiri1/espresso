#  Supercell
These are the input files for the 4 by 4 by 4 GaAs using LDA pseudopotentials
