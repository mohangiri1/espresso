This is the tutorial for using banduppy with QuantumEspresso (QE).  You may run it by executing the `run_banduppy.py`
script, just modifying the  commands to call QE on ypur system.  

The input files are in `./input` directory 
The outputs that one  should get are in `./reference`

Please, examine the `run_banduppy.py`  script, and modify it to your needs, e.g. to produce inputs and run other abinitio codes.
You may also make use of more advanced simulation environments, like `ASE <https://wiki.fysik.dtu.dk/ase/>`__  .

